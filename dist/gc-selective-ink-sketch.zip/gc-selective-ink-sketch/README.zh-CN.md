# GC Selective Ink Sketch

把用户上传的真实照片转成有取舍、有留白、保留现场笔触的黑白钢笔速写。支持全球建筑、街巷空间、自然风景、人物动态、群像与肖像。

## 核心特点

- 一张照片是唯一事实来源，不机械描边，也不凭空发明结构。
- 每张图只设一个高完成度锚点，其他区域主动降级为基础线、骨架或空白。
- 纯黑色钢笔线；灰度只来自可见排线疏密，不使用水彩、墨水晕染或柔和渐变。
- 保留断线、寻找线、错位重启、干涩缺口和少量修正线，避免矢量化与 AI 插画腔。
- 人物优先保证造型律动；建筑优先保证地域结构与透视；风景优先保证地貌轮廓、尺度和空气留白。

## 使用方式

上传一张 JPG、PNG 或 WebP 照片，然后说：

```text
使用 GC Selective Ink Sketch，把这张照片转成我的钢笔速写。
```

可继续补充：

- `更松，留白再多一点`
- `只刻画门楼，周围快速省略`
- `人物动态优先，破型 strong`
- `不要晕染，中间灰只用方向性排线`

## 黄金样例

- [通过样例：雪山选择性钢笔速写](assets/golden-style-snow-mountain-selective-ink.png)
- [对应源照片](assets/example-source-snow-mountain.jpg)

黄金样例只用于理解“单一局部刻画、空白承担云雪、深黑集中、线条逐级消失”的机制。运行时仍只提交用户自己的源照片，不把样例作为第二张风格参考图。

## 文件结构

```text
gc-selective-ink-sketch/
├── SKILL.md
├── README.zh-CN.md
├── agents/openai.yaml
├── assets/
├── evals/evals.json
└── references/
```
